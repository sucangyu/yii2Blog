# MeepoPS-PHP 简介

- MeepoPS是Meepo PHP Socket的缩写. 旨在提供高效稳定的由纯PHP开发的多进程SocketService.
- MeepoPS可以轻松构建在线实时聊天, 即时游戏, 视频流媒体播放, RPC, 以及原本使用HTTP的接口/定时任务的场景中等.
- 手册地址: [http://meepops.lanecn.com](http://meepops.lanecn.com)
- Github: [https://github.com/lixuancn/MeepoPS-PHP](https://github.com/lixuancn/MeepoPS-PHP)
- Bug提交: [https://github.com/lixuancn/MeepoPS-PHP/issues](https://github.com/lixuancn/MeepoPS-PHP/issues)
- 微博: [http://weibo.com/lanephp](http://weibo.com/lanephp)