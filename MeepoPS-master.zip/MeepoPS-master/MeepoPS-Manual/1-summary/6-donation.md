# 捐助
MeepoPS是免费的, 并且是永久免费. 
 
### 捐赠用途
- 其实感觉没什么卵用, 但是大多项目都有这么一览, 我们也不能免俗-.-

### 捐赠方式
- 微信:

![微信](Image/donation-weixin.jpg?raw=true "微信")

- 支付宝

![支付宝](Image/donation-alipay.jpeg?raw=true "支付宝")

### 捐赠列表
- 林国锋 ￥10
- YiHan ￥0.1
- ★♂偉 ￥0.01