# DEMO

- 基于Telnet协议的Telnet接口类的服务端使用方法请参考demo-telnet.php.
- 基于Http协议的Http接口类的服务端使用方法请参考demo-http.php.
- 基于WebSocket协议的WebSocket接口类的服务端使用方法请参考demo-websocket.php.
- 基于Trident协议的Trident接口类的服务端使用方法请参考demo-trident.php.
- 如果服务端启动的是HOST是0.0.0.0, 那么客户端可以是外机, 可以是本机. 本机可以是127.0.0.1, 也可以是localhost.
- 如果服务端启动的是HOST是127.0.0.1/localhost, 那么客户端是不能外机, 只能是本机.