# 客户端使用方法

### Telnet:
    客户端可使用telnet客户端.如: telnet 127.0.0.1 19910

### 编写代码:
    客户端可借助编程语言的Socket来实现. 可参考Test/test_client.php
