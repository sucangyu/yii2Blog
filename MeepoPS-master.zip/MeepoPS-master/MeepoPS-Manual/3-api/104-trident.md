# Trident接口

新增自V0.0.5

接口类文件为: Api/Trident.php

Trident接口与Telnet接口、WebSocket接口、Http接口不同。 而是一整套的分布式、多进程的解决方案, 因此单独列了一章来说明。Trident在底层, 仍旧使用像Telnet接口、Http接口、WebSocket接口等。

[Trident文档  传送门](../11-trident/1-summary.md)