# WebSocket协议

新增自V0.0.4

WebSocket协议是一个应用层协议, 诞生于HTML5, 是一个长链接。
 
所谓的长链接, 就是一次链接, 长期使用, 不断开。可不是死循环不断发HTTP请求的假长链接哦。

使用WebSocket应用层协议, 需要实例化WebSocket的接口类文件Api\Websocket.php。[使用方法传送门](../3-api/103-websocket.md)

关于WebSocket是什么, 就不多说了, 推荐一个知乎的帖子。[https://www.zhihu.com/question/20215561](https://www.zhihu.com/question/20215561)