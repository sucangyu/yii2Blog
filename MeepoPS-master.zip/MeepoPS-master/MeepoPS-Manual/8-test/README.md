# 测试

- 不同事件, 不同进程的测试. [点击查看](1-event-and-child-proccess.md)
- V0.0.2发布前的测试, 维持十万个链接同时在线, 不间断收发消息. [点击查看](2-push-before.md)
- V0.0.3发布前的测试, Crontab启动ab进行压测HTTP协议。
