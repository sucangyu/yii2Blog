# MeepoPS - 高性能高扩展高可用的PHP Socket服务 使用手册

MeepoPS是Meepo PHP Socket的缩写. 旨在提供高效稳定的由纯PHP开发的多进程SocketService.


MeepoPS可以轻松构建在线实时聊天, 即时游戏, 视频流媒体播放, RPC, 实时监控, 以及原本使用HTTP的接口/定时任务的场景中等. 在下个版本, MeepoPS的HTTP协议在简单场景下是可以替代Apache/Nginx的.


当前版本为V0.0.5