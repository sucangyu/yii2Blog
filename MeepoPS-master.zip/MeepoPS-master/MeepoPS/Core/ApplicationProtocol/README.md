# ApplicationProtocol

本目录是应用层协议目录, 一个协议为一个文件。 如HTTP协议, 是Http.php