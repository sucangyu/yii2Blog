# MeepoPS-PHP

本目录是MeepoPS的文件目录.

在这里有入口文件, 配置文件, 接口文件, MeepoPS核心代码目录文件

使用时,请使用Api目录下文件. Api目录是MeepoPS暴露给应用来继承或实例化的类